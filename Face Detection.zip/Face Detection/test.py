import re
import numpy
from numpy import *
def minion_game(string):
    # your code goes here
    res = [string[i: j] for i in range(len(string)) 
          for j in range(i + 1, len(string) + 1)]
    s=0

    for l in range(len(res)):
        if re.match("^[AEIOU]",res[l]):
            s+=1
        
    k= len(res)-s
    if s>k:
        print("Kevin {0}".format(s))
    elif k>s:
        print("Stuart {0}".format(k))
    else:
        print("Draw")

if __name__ == '__main__':
    s = input()
    minion_game(s)